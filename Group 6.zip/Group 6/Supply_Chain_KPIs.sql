-- INVENTORY KPIs (7)
-- 1) Total Inventory Value (222122)
SELECT SUM(`Quantity on Hand` * `Cost Amount`) AS total_inventory_value FROM mahendra.f_inventory_adjusted;

-- 2) Total Units on Hand (1905)
SELECT SUM(`Quantity on Hand`) AS total_units_on_hand FROM mahendra.f_inventory_adjusted;

-- 3) Average Inventory per Product (1.738)
SELECT AVG(`Quantity on Hand`) AS avg_inventory_per_product FROM mahendra.f_inventory_adjusted;

-- 4) Out-of-Stock Products Count (0)
SELECT COUNT(*) AS out_of_stock_products FROM mahendra.f_inventory_adjusted WHERE `Quantity on Hand` = 0;

-- 5) Low Stock Products Count (1096)
SELECT COUNT(*) AS low_stock_products
FROM mahendra.f_inventory_adjusted
WHERE CAST(`Quantity on Hand` AS UNSIGNED) <= 5;

-- 6) Average Inventory Value per Product (202.66)
SELECT AVG(CAST(`Quantity on Hand` AS UNSIGNED) * CAST(`Cost Amount` AS DECIMAL(10,2))) AS avg_inventory_value_per_product
FROM mahendra.f_inventory_adjusted;

-- 7) Inventory by Product Category
SELECT `Product Type`, SUM(CAST(`Quantity on Hand` AS UNSIGNED)) AS total_units
FROM mahendra.f_inventory_adjusted
GROUP BY `Product Type`;

-- SUPPLY CHAIN KPIs (5)

-- 1) Total Orders (74293)
SELECT COUNT(DISTINCT `Order Number`) AS total_orders
FROM mahendra.f_sales;

-- 2) Total Customers (4559)
SELECT COUNT(DISTINCT `Cust Key`) AS total_customers
FROM mahendra.f_sales;

-- 3)Average Orders per Customer (16)
SELECT COUNT(DISTINCT `Order Number`) / COUNT(DISTINCT `Cust Key`) AS avg_orders_per_customer
FROM mahendra.f_sales;

-- 4) Orders by Purchase Method
SELECT `Purchase Method`, COUNT(*) AS total_orders
FROM mahendra.f_sales
GROUP BY `Purchase Method`;

-- 5) Top 5 Stores by Order Volume
SELECT 
    d.`Store Name`,
    COUNT(s.`Order Number`) AS total_orders
FROM mahendra.f_sales s
JOIN mahendra.d_store d 
    ON s.`Store Key` = d.`Store Key`
GROUP BY d.`Store Name`
ORDER BY total_orders DESC
LIMIT 5;

-- 6) Total Stores Active
SELECT COUNT(DISTINCT `Store Key`) AS total_stores
FROM mahendra.f_sales;




